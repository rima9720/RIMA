package espireCab;
import java.sql.SQLException;

public interface BookingServiceDAO {

	public void showAllBooking() throws SQLException;
}
